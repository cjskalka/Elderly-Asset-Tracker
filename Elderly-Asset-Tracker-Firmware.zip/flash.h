/*
 * flash.h
 *
 *  Created on: Oct 7, 2014
 *      Author: Chris
 */
typedef unsigned char UInt8;

void FlashWrite(UInt8 Length, char* Data, char* Address);
void FlashRead(UInt8 Length, char* Data, char* Address);
void FlashErase(UInt8 Sector);

// Flash addresses, beginning of info memory seg C is 0x107F-0x1040
#define SEG_C_INFO			0x1040
#define PHONE_ADDRESS		0x1040
