
#include "msp430.h"
#include "I2C.h"
#include "MMA8452Q.h"
#include "flash.h"

typedef unsigned char UInt8;
typedef unsigned int UInt16;
typedef unsigned long UInt32;

// Used to enable debug UART print statements
// #define DEBUG

#define SET_GPS_RX_FLAG		(GPSRXFlag = 1)
#define CLR_GPS_RX_FLAG		(GPSRXFlag = 0)
#define SET_STR_RDY			(StringReady = 1)
#define CLR_STR_RDY			(StringReady = 0)
#define SET_MUX_GPS			((P2OUT |= 0x02), (P2OUT &= ~0x04))
#define SET_MUX_DEBUG		((P2OUT &= ~0x02), (P2OUT |= 0x04))
#define SET_MUX_CELL		((P2OUT &= ~0x04), (P2OUT &= ~0x02))
#define SET_LEVEL_OE		(P3OUT |= 0x04)
#define CLR_LEVEL_OE		(P3OUT &= ~0x04)
#define SET_GPS_PWR_ENABLE  (P3OUT |= 0x02)
#define CLR_GPS_PWR_ENABLE  (P3OUT &= ~0x02)
#define SET_CELL_PWR_ENABLE (P2OUT |= 0x10)
#define CLR_CELL_PWR_ENABLE (P2OUT &= ~0x10)
#define SET_GPS_RST			(P3OUT |= 0x40)
#define CLR_GPS_RST			(P3OUT &= ~0x40)
#define SET_CELL_ENABLE		(CellEnable = 1)
#define CLR_CELL_ENABLE		(CellEnable = 0)
#define LED_2_OFF			(P3OUT |= 0x08)
#define LED_2_ON			(P3OUT &= ~0x08)
#define LED_3_OFF			(P1OUT |= 0x20)
#define LED_3_ON			(P1OUT &= ~0x20)
#define SET_BAT_EN			(P1OUT |= 0x10)
#define CLR_BAT_EN			(P1OUT &= ~0x10)
#define SET_MSG_RDY			(MessageReady = 1)
#define CLR_MSG_RDY			(MessageReady = 0)
#define SET_MSG_RX_FLAG		(MessageRXFlag = 1)
#define CLR_MSG_RX_FLAG		(MessageRXFlag = 0)
#define SET_BYTE_READ_FLAG  (ByteRead = 1)
#define CLR_BYTE_READ_FLAG	(ByteRead = 0)
#define SET_MSG_COMPLETE    (MessageComplete = 1)
#define CLR_MSG_COMPLETE	(MessageComplete = 0)
//#define SET_GPS_DATA		(SendGPSData = 1)
//#define CLR_GPS_DATA		(SendGPSData = 0)
#define SET_TEST			(Test = 1)
#define CLR_TEST			(Test = 0)
#define SET_GPS_LOCK		(GPSLock = 1)
#define CLR_GPS_LOCK		(GPSLock = 0)
#define SET_MSG_ERROR		(MessageError = 1)
#define CLR_MSG_ERROR		(MessageError = 0)



// I2C
#define SlaveAddress   		0x1C

// System states
#define SLEEP 				0
#define GPS					1
#define CELL				2
#define START_SYS			3
#define SEND_DATA			4
#define CHECK_MSG			8
#define CONFIG				9
#define HELLO_WORLD			10
#define MAKE_CALL			11
#define GPS_MASK			0x01
#define BATT_MASK			0x02
#define CONFIG_MASK			0x04


UInt8 SendDataType = 0;		// B0 = GPS, B1 = BATT, B2 = CONFIG
UInt8 ByteRead = 0;
UInt8 RXByte = 0;
UInt8 MessageRXFlag = 0;
UInt8 MessageReady = 0;
UInt8 MessageIdx = 0;
UInt8 State = START_SYS;
UInt8 Lat[11];
UInt8 Long[12];
UInt8 StringReady = 0;
UInt8 CellEnable = 0;
UInt8 GPSRXFlag = 0;
UInt8 DelayEnable = 0;
UInt8 RXIdx = 0;
UInt8 RXBuffer[200];
UInt8 EOL[1] = {0x1A};
UInt8 read_val[2];
UInt16 BatteryVoltage = 0;
float Battery = 0;
UInt8 BatteryText[5];
signed char AccData[3] = {0, 0, 0};
UInt8 WriteData[2] = {0, 0};
UInt8 MessageComplete = 0;
//UInt8 SendGPSData = 0;
UInt8 MessageID = 0;
UInt8 GPSLock = 0;
UInt8 MessageError = 0;
UInt8 MessageIndex = 0;
UInt8 ADCCount = 0;
UInt8 LowPowerCount = 0;
UInt8 PhoneNumber[10] = {'1','2','3','4','5','6','7','8','9','9'};
UInt8 PhoneNumber2[10];

UInt8 Test = 0;


void SetupTextMessage(void);
void IntToASCII(UInt8 Num, char* StrPtr);
UInt8 ReadMessage(UInt8 Index);
void ProcessRXByte(UInt8 Index);
void FloatToString(float TargetFloat, UInt8 NumDigits, char* TargetString);
UInt32 StringToLong(char* TargetString, UInt8 Len);
void StringCopy( char* StrToCpy, char* Dest, UInt8 Len);
void CalculatePosition(void);
UInt8 GetGPSLock(void);
UInt8 StringCompare(char* CmprStrPtr, char* OrigStrPtr, UInt8 Length);
UInt8 CellUARTWrite(char* StringPtr, UInt8 Length);
UInt8 DebugUARTWrite(char* StringPtr, UInt8 Length);
void Delay(UInt16 Time);
void EraseMessage(UInt8 Delete);
void ClearRXBuffer(void);
void ProcessMessage(void);
void TurnOnCell(void);
void LowPowerDelay(void);
void EraseAllMessages(void);
void SendHelloWorld(void);
void MakeCall(void);
void TurnOnGPS(void);
void InitAcc(void);
void MeasureBattery(void);

int main(void)
{
   WDTCTL = WDTPW + WDTHOLD;                // Stop WDT
  if (CALBC1_16MHZ == 0xFF)					// If calibration constant erased
  {
    while(1);                               // do not load, trap CPU!!
  }
  DCOCTL = 0;                               // Select lowest DCOx and MODx settings
  BCSCTL1 = CALBC1_16MHZ;                   // Set DCO
  DCOCTL = CALDCO_16MHZ;
  P1SEL = BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
  P1SEL2 = BIT1 + BIT2 ;                    // P1.1 = RXD, P1.2=TXD
  UCA0CTL1 |= UCSSEL_2;                     // SMCLK = 16MHz
  UCA0BR0 = 130;                            // 16MHz 9600
  UCA0BR1 = 6;                              // 16MHz 9600
  UCA0MCTL = UCBRS0;                        // Modulation UCBRSx = 1
  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt
  //IE2 |= UCA0TXIE;                        // Enable USCI_A0 TX interrupt
  TACCTL0 = CCIE;                           // Timer A0 interrupt enabled
  BCSCTL3 |= LFXT1S_2;						// Set ACLK to VLO ~12kHz
  //BCSCTL3 |= XCAP_3;						// Set ACLK to the external 32.768kHz crystal with 12.5pF loading
  //BCSCTL1 |= DIVA_3;						// ACLK/8

  ADC10CTL0 = ADC10SHT_2 + ADC10ON + ADC10IE; // ADC10ON, interrupt enabled
  ADC10CTL1 = INCH_3;                       // ADC input A3
  ADC10AE0 |= 0x08;                         // PA.3 ADC option select

  FCTL2 = FWKEY + 0x29;						// Must write FWKEY, default clock is MCLK (16MHz), 0x29 sets Ftg clock divider for 400kHz



  P2IE |= 0x20;								// P2.5 Button interrupt enabled
  P2IES &= 0x20;							// P2.5 high/low edge
  P2IFG &= ~0x20;							// P2.5 IFG cleared
  P2DIR &= ~0x20;							// interrupt from BUTTON

  P1IE |= 0x01;							    // P1.0 RI interrupt enabled
  P2IES &= ~0x01;							// P1.0 high/low edge
  P2IFG &= ~0x01;							// P1.0 IFG cleared
  P1DIR &= ~0x01;							// Set P1.0 input for RI

  P2IE |= 0x08;                             // P2.3 ACC interrupt enabled
  P2IES |= 0x08;                            // P2.3 low/high edge
  P2IFG &= ~0x08;                           // P2.3 IFG cleared
  P2DIR &= ~0x08;							// interrupt pin on ACC


  P1DIR |= 0x10;							// Set P1.4 output for MSP_BAT_EN
  P2DIR &= ~0x20;							// Set P2.5 input for BUTTON
  P3DIR |= 0x02;							// Set P3.1 output for GPS_PWR_EN
  P3DIR |= 0x40;							// Set P3.6 output for GPS_RST_N
  P2DIR |= 0x01;							// Set P2.0 output for CELL_RESET_N
  P3DIR |= 0x04;							// Set P3.2 output for LEVEL_OE
  P3DIR |= 0x01;							// Set P3.0 output for CELL_PWRKEY
  P1DIR |= 0x20;							// Set P1.5 output for LED3
  P3DIR |= 0x08;							// Set P3.3 output for LED2
  P2DIR |= 0x06;							// Set P2.1 and P2.2 to output for mux
  P2DIR |= 0x10;							// Set P2.4 output for cell power enable



  LED_2_OFF;
  LED_3_OFF;
  CLR_GPS_PWR_ENABLE;
  CLR_CELL_PWR_ENABLE;
  CLR_GPS_RST;

  __bis_SR_register(GIE);       		    // interrupts enabled



  while(1)
  {

	  switch(State)
	  {
	  	  case SLEEP:
	  	  _BIS_SR(LPM3_bits + GIE);
	  	  break;

	  	  case MAKE_CALL:
	  	  MakeCall();
	  	  _BIS_SR(LPM3_bits + GIE);
	  	  break;

	  	  case CONFIG:

	  	  LED_3_ON;
	  	  //FlashErase(3);
	  	  //FlashWrite(10, (char*)PhoneNumber, (char*)PHONE_ADDRESS);
	  	  FlashRead(10, (char*)PhoneNumber2, (char*)PHONE_ADDRESS);
	  	  LED_2_ON;
	  	  while(1);
	  	  break;


	  	  case HELLO_WORLD:
	  	  SendHelloWorld();
	  	  while(1);
	  	  break;

	  	  case START_SYS:
	  	  Delay(1000);
	  	  TurnOnCell();
	  	  Delay(1000);
	  	  EraseAllMessages();
	  	  //TurnOnGPS();
	  	  InitAcc();
	  	  Delay(1000);
	  	  //CellUARTWrite("AT+CFUN=1,0\r\n", 13);		// reduced power mode, RI still works
	  	  State = SLEEP;
	  	  break;


	  	  case GPS:
	  	  ProcessRXByte(RXIdx);
	  	  if(StringReady)
	  	  {
	  			  if(StringCompare("$GPRMC", (char*)RXBuffer, 6))
	  			  {
	  				  if(GetGPSLock())
	  				  {
#ifdef DEBUG
	  					  DebugUARTWrite("\r\n", 4);				// Prints all GPS Strings
#endif
	  					  DebugUARTWrite((char*)RXBuffer, 120);
	  					  IE2 &= ~UCA0RXIE;                         // Disable USCI_A0 RX interrupt
	  					  CalculatePosition();
	  					  IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt
#ifdef DEBUG
	  					  DebugUARTWrite("\r\n", 4);
#endif
	  					  SET_MUX_CELL;
	  					  LED_2_ON;									// Turn on LED to indicate GPS lock
	  					  SET_GPS_LOCK;
	  				  }
	  				  else
	  				  {
#ifdef DEBUG
	  					 DebugUARTWrite("Searching...\r\n", 16);
#endif
	  					 LED_2_OFF;
	  					 SET_MUX_GPS;
	  				  }
	  			  }
	  			  CLR_STR_RDY;
	  	  }
	  	  State = SEND_DATA;
	  	  break;

	  	  case SEND_DATA:

	  	  if(SendDataType & GPS_MASK)				// Detect a button press
	  	  {
	  		  if(GPSLock)
	  		  {
	  			  SendDataType &= ~GPS_MASK;
	  			  SetupTextMessage();
	  			  CellUARTWrite((char*)Lat, 11);
	  			  Delay(200);
	  			  CellUARTWrite("  ", 2);
	  			  Delay(200);
	  			  CellUARTWrite((char*)Long, 12);
	  			  Delay(200);
	  			  CellUARTWrite((char*)EOL, 1);
	  			  Delay(16000);
	  			  LED_3_OFF;
	  			  LED_2_OFF;
	  			  State = CHECK_MSG;
	  			  break;
	  		  }
		  	  State = GPS;
	  	  }
	  	  else if(SendDataType & BATT_MASK)
	  	  {
	  		  SendDataType &= ~BATT_MASK;
	  		  SetupTextMessage();
	  		  CellUARTWrite("Battery Voltage: ", 17);
	  		  Delay(200);
	  		  CellUARTWrite((char*)BatteryText, 5);
	  		  Delay(200);
	  		  CellUARTWrite((char*)EOL, 1);
	  		  Delay(16000);
	  		  LED_3_OFF;
	  		  State = CHECK_MSG;
	  		  break;
	  	  }
	  	  break;


	  	  case CHECK_MSG:
	      __bis_SR_register(GIE);
	  	  if(!CellEnable)						// Turn on cell modem if not already on
	  	  {
	  		  TurnOnCell();
	  		  SET_CELL_ENABLE;
	  	  }

	  	  if(!MessageError && (MessageComplete || MessageIndex <= 0))						// Checks to see if it is OK to read the next message from SIM
	  	  {

	  		  CLR_MSG_COMPLETE;
	  		  ClearRXBuffer();
	  		  MessageIndex++;
	  		  ReadMessage(MessageIndex);		// Read messages, this should be a variable...
	  	  }
	  	  ProcessMessage();						// Main function of this state...
 	  	  if(MessageComplete)
	  	  {

	  		  switch(MessageID)
	  		  {
	  		  	  case '1':			// Send GPS data
	  		  	  SendDataType |= GPS_MASK;
	  		  	  TurnOnGPS();
	  		  	  State = GPS;
	  		  	  break;

	  		  	  case '2':			// Send battery voltage
	  		  	  SendDataType |= BATT_MASK;
	  		  	  //State = BATT_MEAS;
	  		  	  break;

	  		  	  case '3':			// Set phone number
	  		  	  SendDataType |= CONFIG_MASK;
	  		  	  //State = CONFIG;
	  		  	  break;

	  		  	  default:
	  		  	  break;
	  		  }
	  		  //EraseMessage(MessageIndex);		// Delete message
	  		  ClearRXBuffer();
	  		  MessageID = 0;
	  	  }
	  	  else if(MessageError)					// Checks to see if message index is greater than number of messages
	  	  {
	  		  if(StringCompare("OK", (char*)RXBuffer, 2));
	  		  {
	  			  State = SLEEP;
	  			  //Delay(1);
	  		  }
	  		  CLR_MSG_ERROR;
	  	  }
	  	  else
	  	  {
	  		  //MessageIndex++;
	  	  }

	  	  break;

	  }
  }


  //__bis_SR_register(LPM0_bits + GIE);       // Enter LPM0, interrupts enabled

}

void MeasureBattery(void)						    // 645-745 is range of VBAT, 2.5V to 4.2V
{
	for(ADCCount = 0; ADCCount < 3; ADCCount++)     // Sample a few times before saving voltage
	{
		SET_BAT_EN;							    	// Turn on voltage divider circuit
		ADC10CTL0 |= ENC + ADC10SC;               	// Sampling and conversion start
		__bis_SR_register(CPUOFF + GIE);          	// LPM0, ADC10_ISR will force exit
		BatteryVoltage = ADC10MEM;			    	// Read ADC conversion register
	}
	Battery = (float).8*BatteryVoltage/(float)58 - (float)6.07;	 // y = 1.7/100 - 8.46
	Battery = Battery/10;							// Due to how FloatToString was written, need to divide by 10 since not converting coordinates

	FloatToString(Battery, 3, (char*)BatteryText);
	BatteryText[4] = BatteryText[1];
	BatteryText[3] = BatteryText[2];
	BatteryText[1] = '.';
	BatteryText[2] = BatteryText[4];
	BatteryText[3] = BatteryText[3];
	BatteryText[4] = 'V';
}

void InitAcc(void)
{


	InitI2C(SlaveAddress);					// Initialize MSP430 as I2C master
	read_val[0] = I2CRead(WHO_AM_I);       // Read WHO_AM_I register, should return 0x2A
	if(read_val[0] == 0x2A)
	{
		LED_2_ON;
		LED_3_ON;
		Delay(200);
	}

		LED_2_OFF;
		LED_3_OFF;

		InitAccInt();								// Initialize accelerometer
		__bis_SR_register(GIE);       		    // interrupts enabled
}

void TurnOnGPS(void)
{
	SET_GPS_PWR_ENABLE;						// Enable P3.3VD_GPS power
	Delay(20);
	SET_GPS_RST;
	Delay(200);
	CLR_GPS_RST;
	Delay(200);
	State = GPS;
	SET_MUX_GPS;								// Prepare to receive GPS data
	IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt
}

void MakeCall(void)
{

	LED_3_ON;
	P3DIR |= 0x04;
	SET_LEVEL_OE;
	P3OUT |= 0x04;
	CellUARTWrite("AT\r\n", 4);
	Delay(200);
	CellUARTWrite("AT\r\n", 4);
	Delay(200);
	CellUARTWrite("AT+CMGF=1\r\n", 11);
	Delay(200);
	CellUARTWrite("AT+CMIC=0,8\r\n", 12);
	Delay(200);
	CellUARTWrite("AT+CLVL=90\r\n", 12);
	Delay(200);
	CellUARTWrite("AT+CHFA=0\r\n", 11);	//default is 0, not necessary
	Delay(200);
	CellUARTWrite("AT+ECHO=0,7,2,0\r\n", 17);
	Delay(200);
	CellUARTWrite("AT+SIDET=0,8\r\n", 13);
	Delay(200);
	CellUARTWrite("ATD8587762593;\r\n", 16);

}

void SendHelloWorld(void)
{
	TurnOnCell();
	Delay(2000);
	SetupTextMessage();
	CellUARTWrite("Sup World", 9);
	Delay(200);
	CellUARTWrite((char*)EOL, 1);

}

void EraseAllMessages(void)
{
	// DUDE using the wrong AT command should be cmgda
	//This function is broken, should be at+cmgd=index,4; where index must be an valid message
	ClearRXBuffer();
	SET_MUX_CELL;
	SET_LEVEL_OE;
	CellUARTWrite("AT\r\n", 4);
	Delay(200);
	//__delay_cycles(1000);
	//Delay(200);
	CellUARTWrite("AT+CMGF=1\r\n", 11);			// Puts modem in text mode, not PDU mode
	Delay(200);
	//__delay_cycles(1000);
	CellUARTWrite("AT+CMGDA=\"DEL ALL\"\r\n", 20);		// Erase all messages
	//__delay_cycles(1000);
	Delay(10000);
}

void TurnOnCell(void)
{
	LED_2_ON;
	SET_CELL_PWR_ENABLE;
	P2OUT |= 0x01;							// Assert RESET_N
	Delay(1000);
	P2OUT &= ~0x01;	  						// Release RESET_N
    Delay(1000);
	P3OUT |= 0x01;							// Hold PWR_KEY for ~1 second
 	Delay(1000);
    P3OUT &= ~0x01;							// Release PWR_KEY
    Delay(1);

    Delay(16000);							// Add all these stupid delays because AT+CREG keeps saying it's not on the network
    //Delay(16000);							// need to troubleshoot this with the stand alone GSM board but for now the
    //Delay(16000);							// delays will wait long enough to get registered on the network
    //Delay(16000);
    //Delay(16000);
    //Delay(16000);
    LED_2_OFF;
    SET_CELL_ENABLE;


    //CellUARTWrite("AT+CREG=?\r\n", 11);
    //Delay(200);
    // NEED to trap or set flag with AT+CREG command to request	network registration or to read registration status

}

void TurnOffCell(void)
{

	P2OUT |= 0x01;							// Assert RESET_N
	Delay(1000);
	P3OUT |= 0x01;							// Hold PWR_KEY for ~1 second
 	Delay(1000);
    P3OUT &= ~0x01;							// Release PWR_KEY
    //Delay(1000);
    CLR_CELL_PWR_ENABLE;

}

void SetupTextMessage(void)
{
	  SET_MUX_CELL;
	  LED_3_ON;
	  P3DIR |= 0x04;
	  SET_LEVEL_OE;
	  P3OUT |= 0x04;
	  CellUARTWrite("AT\r\n", 4);
	  Delay(200);
	  CellUARTWrite("AT\r\n", 4);
	  Delay(200);
	  CellUARTWrite("AT+CMGF=1\r\n", 11);
	  Delay(200);
	  CellUARTWrite("AT+CMGS=\"8587762593\",\r\n", 23);
	  Delay(200);
}

void ClearRXBuffer(void)
{
	UInt8 i;

	for(i = 0; i < 120; i++)
	{
		RXBuffer[i] = 0;
	}
}

void EraseMessage(UInt8 Delete)
{

	UInt8 Message[14] = {'A','T','+','C','M','G','D','=', ' ', ' ', ',', '0', '\r','\n'};
	SET_LEVEL_OE;
	IntToASCII(Delete, (char*)(Message + 8));
	CellUARTWrite("AT\r\n", 4);
    Delay(200);
    RXIdx = 0;
    //CellUARTWrite("AT+CMGD=4,0\r\n", 13);		// Erase all messages
    CellUARTWrite("AT+CMGF=1\r\n", 11);
    Delay(200);
	CellUARTWrite((char*)Message, 14);
	Delay(200);
	CellUARTWrite("\r\n", 2);
    Delay(200);
}

UInt8 ReadMessage(UInt8 Index)
{
	//UInt8 Message[12] = {'A','T','+','C','M','G','R','=',0,0,'\r','\n'};
	UInt8 Message[1] = {0};
	SET_LEVEL_OE;
	IntToASCII(Index, (char*)Message);
	CellUARTWrite("AT\r\n", 4);
    Delay(200);

    CellUARTWrite("AT+CMGF=1\r\n", 11);
    Delay(200);
    CellUARTWrite("AT+CMGR=", 8);
    CellUARTWrite((char*)Message, 1);
	CellUARTWrite("\r\n", 2);
    //CellUARTWrite("AT+CMGR=1\r\n", 11);
    //while(1);
	RXIdx = 0;

	return 1;
}

void IntToASCII(UInt8 Num, char* StrPtr)	// NEED TO FIX!!!, NEED TO INSERT SPACES INSTEAD OF ZEROS
{
	UInt8 Temp = 0;

	if(Num > 99)
	{
		Temp = Num/100;
		*StrPtr = Temp + 0x30;
		StrPtr++;
		Num = Num - (100 * Temp);
	}
	if(Num > 9)
	{
		Temp = Num/10;
		*StrPtr = Temp + 0x30;
		StrPtr++;
		Num = Num - (10 * Temp);
	}
	*StrPtr = Num + 0x30;

}

void FloatToString(float TargetFloat, UInt8 NumDigits, char* TargetString)
{
	UInt32 TargetLong = 0;
	UInt32 MSB = 0;
	UInt8 i = 0;

	TargetLong = TargetFloat*1000000;
	for(i = 0; i < NumDigits; i++)
	{
		switch(i)
		{
			case 0:
			MSB = (TargetLong/(UInt32)100000);
			*TargetString = (UInt8)((TargetLong/100000) + 0x30);
			break;

			case 1:
			TargetLong = TargetLong - MSB*(100000);
			MSB = (TargetLong/(UInt32)10000);
			*TargetString = ((UInt8)(TargetLong/10000) + 0x30);
			break;

			case 2:
			TargetLong = TargetLong - MSB*(10000);
			MSB = (TargetLong/(UInt32)1000);
			*TargetString = ((UInt8)(TargetLong/1000) + 0x30);
			break;

			case 3:
			TargetLong = TargetLong - MSB*(1000);
			MSB = (TargetLong/(UInt32)100);
			*TargetString = ((UInt8)(TargetLong/100) + 0x30);
			break;

			case 4:
			TargetLong = TargetLong - MSB*(100);
			MSB = (TargetLong/(UInt32)10);
			*TargetString = ((UInt8)(TargetLong/10) + 0x30);
			break;

			case 5:
			TargetLong = TargetLong - MSB*(10);
			MSB = (TargetLong/(UInt32)1);
			*TargetString = ((UInt8)(TargetLong/1) + 0x30);
			break;
		}
		TargetString++;
	}

}

UInt32 StringToLong(char* TargetString, UInt8 Len)
{
	UInt32 Result = 0;
	UInt8 i;

	for(i = 0; i < Len; i++)
	{
		switch(i)
		{
			case 0:
			Result = Result + (UInt32)((*TargetString - 0x30)*100000);
			break;

			case 1:
			Result = Result + ((UInt32)(*TargetString - 0x30)*10000);
			break;

			case 2:
			Result = Result + ((UInt32)(*TargetString - 0x30)*1000);
			break;

			case 3:
			Result = Result + ((UInt32)(*TargetString - 0x30)*100);
			break;

			case 4:
			Result = Result + ((UInt32)(*TargetString - 0x30)*10);
			break;

			case 5:
			Result = Result + ((UInt32)(*TargetString - 0x30));
			break;
		}
		TargetString++;
	}

	return Result;
}

void StringCopy( char* StrToCpy, char* Dest, UInt8 Len)
{
	UInt8 i;
	for(i = 0; i < Len; i++)
	{
		*Dest = *StrToCpy;
		Dest++;
		StrToCpy++;
	}
}

void CalculatePosition(void)
{
	UInt8 TempBuf[11];
	UInt8 PositionBuf[12];
	UInt32 PosNum = 0;
	float TruePos = 0;

	//copy over 20-28
	StringCopy( (char*)(RXBuffer + 20), (char*)PositionBuf, 11);
	TempBuf[0] = PositionBuf[2];
	TempBuf[1] = PositionBuf[3];
	TempBuf[2] = PositionBuf[5];
	TempBuf[3] = PositionBuf[6];
	TempBuf[4] = PositionBuf[7];
	TempBuf[5] = PositionBuf[8];

	PosNum = StringToLong((char*)TempBuf, 6);
	TruePos = (float)PosNum/(float)600000;
	FloatToString(TruePos, 6, (char*)(Lat + 3));
	Lat[0] = PositionBuf[0];
	Lat[1] = PositionBuf[1];
	Lat[2] = '.';
	Lat[9] = ' ';
	Lat[10] = PositionBuf[10];

	DebugUARTWrite((char*)Lat, 11);
	DebugUARTWrite("  ", 2);

	//copy over 32-41
	StringCopy( (char*)(RXBuffer + 32), (char*)PositionBuf, 12);
	TempBuf[0] = PositionBuf[3];
	TempBuf[1] = PositionBuf[4];
	TempBuf[2] = PositionBuf[6];
	TempBuf[3] = PositionBuf[7];
	TempBuf[4] = PositionBuf[8];
	TempBuf[5] = PositionBuf[9];

	PosNum = StringToLong((char*)TempBuf, 6);
	TruePos = (float)PosNum/(float)600000;
	FloatToString(TruePos, 6, (char*)(Long + 4));
	Long[0] = PositionBuf[0];
	Long[1] = PositionBuf[1];
	Long[2] = PositionBuf[2];
	Long[3] = '.';
	Long[10] = ' ';
	Long[11] = PositionBuf[11];

	DebugUARTWrite((char*)Long, 12);

}

UInt8 GetGPSLock(void)
{
	if(RXBuffer[18] == 'A')
	{
		return 1;
	}
	return 0;
}

UInt8 StringCompare(char* CmprStrPtr, char* OrigStrPtr, UInt8 Length)
{
	UInt8 i;
	UInt8 Match = 1;
	for(i = 0; i < Length; i++)
	{
		if(*CmprStrPtr == *OrigStrPtr)
		{
			CmprStrPtr++;
			OrigStrPtr++;
		}
		else
		{
			Match = 0;
			break;
		}
	}
	return Match;
}

void Delay(UInt16 Time)	//time in ms, max time for time == 65535 is 15 seconds of delay
{
	/*DelayEnable = 1;
	TACCR0 = 120*Time;
	TA0CTL = TASSEL_1 + MC_1;
	while(DelayEnable);*/
	UInt16 i;

	for(i = 0; i < Time; i++)
	{
		__delay_cycles(15990);
	}
}

void LowPowerDelay()
{

	if(LowPowerCount == 1)
	{
		// Exit low power mode
	}
	else
	{
		TACCR0 = 0xFFF;
		TA0CTL = TASSEL_1 + MC_1 + ID_3;
		_BIS_SR(LPM3_bits + GIE);               // Enter LPM3
	}
}

UInt8 DebugUARTWrite(char* StringPtr, UInt8 Length)
{
	UInt8 i;
	SET_MUX_DEBUG;
	for(i = 0; i < Length; i++)
	{
		while (!(IFG2&UCA0TXIFG));
		UCA0TXBUF = *StringPtr;
		StringPtr++;
	}
	return 1;
}

UInt8 CellUARTWrite(char* StringPtr, UInt8 Length)
{
	UInt8 i;
	SET_LEVEL_OE;
	SET_MUX_CELL;
	for(i = 0; i < Length; i++)
	{
		while (!(IFG2&UCA0TXIFG));
		UCA0TXBUF = *StringPtr;
		StringPtr++;
	}
	return 1;
}

void ProcessMessage(void)
{
	switch(RXByte)
	{
		case '#':
		SET_MSG_RX_FLAG;
		break;

		case '@':
		CLR_MSG_RX_FLAG;
		SET_BYTE_READ_FLAG;
		MessageID = RXBuffer[9];
		SET_MSG_COMPLETE;
		RXIdx = 0;
		break;

		case 'O':
		SET_MSG_RX_FLAG;
		break;

		case 'K':
		CLR_MSG_RX_FLAG;
		SET_BYTE_READ_FLAG;
		SET_MSG_ERROR;
		RXIdx = 0;
		break;

		default:
		break;

	}

	if(MessageRXFlag && !(ByteRead))
	{
		RXBuffer[RXIdx] = RXByte;
		RXIdx++;
		SET_BYTE_READ_FLAG;
	}
}

void ProcessRXByte(UInt8 Index)
{

	switch(RXByte)
	{
	  	case '$':
	  	SET_GPS_RX_FLAG;
		break;

	  	case 0x0D:
	  	CLR_GPS_RX_FLAG;
	  	SET_BYTE_READ_FLAG;
	  	SET_STR_RDY;
	  	RXIdx = 0;
	  	break;


	  	default:
	  	break;
	}

	if(GPSRXFlag && !(ByteRead))
	{
		RXBuffer[RXIdx] = RXByte;
		RXIdx++;
		SET_BYTE_READ_FLAG;
	}


}


/////////////////////////////////////////INTERUPT SERVICE ROUTINES////////////////////////////////////////////
// Port 2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
	if(P2IFG & 0x08)							  // Accelerometer interrupt
	{
		P2IFG &= ~0x08;                           // P2.4 IFG cleared
		//read_val[0] = I2CRead(FF_MT_SRC);	 	  // Clear accelerometer register by reading (for motion interrupt)
		ClearAccInt();
		LED_2_ON;
		MakeCall();
	}
	if(P2IFG & 0x20)							  // Button interrupt
	{
		P2IFG &= ~0x20;
		//EraseAllMessages();
		LED_2_ON;
		LED_3_ON;
		State = HELLO_WORLD;
	}
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
	if(P1IFG & 0x01)							  // RI interrupt
	{

		P1IFG &= ~0x01;
		if(CellEnable)
		{
			State = CHECK_MSG;
			__bic_SR_register_on_exit(LPM3_bits|GIE);
		}
	}

}

// Timer A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_0 (void)
{
	DelayEnable = 0;

	LowPowerCount++;
	//_BIC_SR_IRQ(LPM3_bits);                   // Clear LPM3 bits from 0(SR)


}


//  Echo back RXed character, confirm TX buffer is ready first
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
  RXByte = UCA0RXBUF;
  //RXBuffer[RXIdx++] = RXByte;				// Used for debug, saves everything in buffer
  CLR_BYTE_READ_FLAG;

}

// ADC10 interrupt service routine
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
  __bic_SR_register_on_exit(CPUOFF);        // Clear CPUOFF bit from 0(SR)
}
