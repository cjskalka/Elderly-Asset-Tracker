void ReadXYZ(char* Data);
void AccStandby(void);
void AccActive(void);
void InitAccInt(void);
void ClearAccInt(void);

#define X_ACC				0
#define Y_ACC				1
#define Z_ACC				2

//Define a few of the registers that we will be accessing on the MMA8452
#define OUT_X_MSB 			0x01
#define OUT_Y_MSB			0x03
#define OUT_Z_MSB			0x05
#define XYZ_DATA_CFG 		0x0E
#define WHO_AM_I 			0x0D
#define CTRL_REG1 			0x2A
#define SYSMOD				0x0B
#define FF_MT_SRC			0x16
