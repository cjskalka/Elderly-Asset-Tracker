#include "MMA8452Q.h"
#include "I2C.h"
typedef unsigned char UInt8;


void InitAccFall(void)
{

	//This function initializes the MMA8452Q for 2g mode, free fall interrupt enable
	I2CWrite(0x2A, 0x20);  			// Set ODR to 50Hz and puts acc into standby
	I2CWrite(0x15, 0xB8);			// Enable freefall detection, latch interrupt (clear on read)
	I2CWrite(0x17, 0x03);			// G threshold, < 0.2g, .2g/.063g = 3.17 so 3 counts
	I2CWrite(0x18, 0x06);			// sets the debounce counter to 120ms
	I2CWrite(0x2D, 0x04);			// Enable freefall interrupt
	I2CWrite(0x2E, 0x20);			// Route interrupt to INT1 of MMA8452Q
	AccActive();

}

void InitAccTrans(void)
{
     //This function initializes the MMA8452Q for 2g mode, transient interrupt enable
     I2CWrite(0x2A, 0x38);  		// Set ODR to 1.56Hz and puts acc into standby
	 I2CWrite(0x1D, 0x1E);			// Enable XYZ transient detection, latch interrupt (clear on read)
	 I2CWrite(0x1F, 0x08);			// G threshold, .5g/.063g = 7.93 so 8 counts
	 I2CWrite(0x20, 0x05);			// sets the debounce counter to 50ms
	 I2CWrite(0x2D, 0x20);			// Enable transient interrupt
	 I2CWrite(0x2E, 0x20);			// Route interrupt to INT1 of MMA8452Q
	 AccActive();
}

void AccStandby(void)
{
	UInt8 Temp = 0;
	Temp = I2CRead(CTRL_REG1);
	I2CWrite(CTRL_REG1, Temp & ~(0x01));  //Clear active bit and go into standby

}

void AccActive(void)
{
	UInt8 Temp = 0;
	Temp = I2CRead(CTRL_REG1);
	I2CWrite(CTRL_REG1, (Temp | 0x01));  //Set active bit and go into standby
}

void ReadXYZ(char* Data)
{

	Data[X_ACC] = I2CRead(OUT_X_MSB);
	Data[X_ACC + 1] = I2CRead(OUT_Y_MSB);
	Data[X_ACC + 2] = I2CRead(OUT_Z_MSB);

}

void ClearAccInt(void)
{
	I2CRead(0x1E);	//Clear Trans Int
	I2CRead(0x16);	//Clear FF Int
}
