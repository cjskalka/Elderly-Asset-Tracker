


#include "msp430.h"
#include "flash.h"


void FlashRead(UInt8 Length, char* Data, char* Address)
{
	UInt8 i = 0;

	FCTL1 = FWKEY;
	FCTL3 = FWKEY;                            // Clear Lock bit

//	FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation

	for(i = 0; i < Length; i++)
	{
		*Data++ = *Address++;
	}

    FCTL1 = FWKEY;                            // Clear WRT bit
	FCTL3 = FWKEY + LOCK;                     // Set LOCK bit

}

void FlashErase(UInt8 Sector)
{
	char* Flash_ptr;

	//Sector 4 downto 1 == info sector D downto A
	if(Sector == 3)		// Sector C
	{
		Flash_ptr = (char *) 0x1040;              // Initialize Flash pointer
		FCTL1 = FWKEY + ERASE;                    // Set Erase bit
		FCTL3 = FWKEY;                            // Clear Lock bit
		*Flash_ptr = 0;                           // Dummy write to erase Flash segment
	}

}

void FlashWrite(UInt8 Length, char* Data, char* Address)
{
	UInt8 i = 0;

	FCTL1 = FWKEY;
	FCTL3 = FWKEY;                            // Clear Lock bit

	FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation

	for(i = 0; i < Length; i++)
	{
		*Address++ = *Data++;
	}

    FCTL1 = FWKEY;                            // Clear WRT bit
	FCTL3 = FWKEY + LOCK;                     // Set LOCK bit
}
